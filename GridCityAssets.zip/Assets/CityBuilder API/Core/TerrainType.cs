﻿namespace Citybuilder.Core {
    public enum TerrainType {
        Water,
        Land
    }
}
