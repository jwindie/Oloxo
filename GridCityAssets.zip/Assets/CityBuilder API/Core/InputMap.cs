﻿using UnityEngine;

namespace Citybuilder.Core {
    public static class InputMap {

        public const KeyCode KEY_BEGIN_DRAG_AREA = KeyCode.LeftShift;
        public const KeyCode TOGGLE_PAINT_STATE = KeyCode.Tab;

    }
}
