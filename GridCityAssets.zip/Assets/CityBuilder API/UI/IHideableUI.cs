﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Citybuilder.UI {
    public interface IHideableUI {
        void Show (bool state);
    }
}
