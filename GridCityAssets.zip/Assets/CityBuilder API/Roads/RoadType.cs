﻿namespace Citybuilder.Roads {
    public enum RoadType {
        None,
        Basic
    }
}
