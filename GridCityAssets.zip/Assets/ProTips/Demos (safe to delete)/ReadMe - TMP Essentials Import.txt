Note on running the TextMeshPro demo scenes for the first time:

When you first open one of the TextMeshPro demo scenes, a popup box should ask you if you want to import
TextMeshPro Essentials. Click 'Yes' to import TMP Essentials when prompted. If you don't, you will get
errors or unexpected behavior (like %BodyText% fields appearing in your tooltips instead of the text you
set).

If you've already closed that popup without importing TMP Essentials, no worries. Just go to the Unity top
menu and choose Window => TextMeshPro => Import TMP Essential Resources.