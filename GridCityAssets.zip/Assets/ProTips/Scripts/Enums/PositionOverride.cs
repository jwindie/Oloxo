﻿
namespace ModelShark
{
    public enum PositionOverride
    {
        MouseCursor = 0,
        Transform = 1,
        Vector = 2
    }
}
