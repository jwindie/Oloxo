﻿
namespace ModelShark
{
    public enum PositionBounds
    {
        Collider,
        Renderer
    }
}
